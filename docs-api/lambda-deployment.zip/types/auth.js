"use strict";
// Authentication types for API Gateway Cognito authorizer context
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRole = void 0;
// User roles for authorization
var UserRole;
(function (UserRole) {
    UserRole["ADMIN"] = "admin";
    UserRole["USER"] = "user";
    UserRole["VIEWER"] = "viewer";
})(UserRole || (exports.UserRole = UserRole = {}));
//# sourceMappingURL=auth.js.map