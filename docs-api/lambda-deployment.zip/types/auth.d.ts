export interface CognitoUser {
    sub: string;
    email?: string;
    email_verified?: boolean;
    given_name?: string;
    family_name?: string;
    'cognito:username'?: string;
    'cognito:groups'?: string[];
    username?: string;
    iss?: string;
    aud?: string;
    client_id?: string;
    token_use?: string;
    scope?: string;
    auth_time?: number;
    exp?: number;
    iat?: number;
    jti?: string;
    origin_jti?: string;
    event_id?: string;
}
export interface AuthorizerContext {
    principalId: string;
    claims: CognitoUser;
    sourceIp: string;
    userAgent: string;
}
export interface APIGatewayProxyEventV2WithAuth {
    requestContext: {
        authorizer?: {
            jwt?: {
                claims: CognitoUser;
                scopes?: string[];
            };
        };
        http: {
            method: string;
            path: string;
            sourceIp: string;
            userAgent: string;
        };
    };
}
export interface AuthenticatedUser {
    userId: string;
    email: string | null;
    username: string | null;
    groups: string[];
    isAdmin: boolean;
}
export declare enum UserRole {
    ADMIN = "admin",
    USER = "user",
    VIEWER = "viewer"
}
export interface AuthContext {
    user: AuthenticatedUser | null;
    isAuthenticated: boolean;
}
//# sourceMappingURL=auth.d.ts.map