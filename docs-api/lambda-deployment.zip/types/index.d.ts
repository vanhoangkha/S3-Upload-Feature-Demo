export interface Document {
    user_id: string;
    file: string;
    id?: string;
    title: string;
    description?: string;
    fileSize: number;
    mimeType: string;
    s3Key: string;
    uploadedBy: string;
    createdAt: string;
    updatedAt: string;
    bucket?: string;
    itemType: 'file' | 'folder';
    folderPath: string;
    isActive?: boolean;
}
export interface CreateDocumentRequest {
    title: string;
    description?: string;
    fileName: string;
    fileSize: number;
    mimeType: string;
    user_id: string;
    folderPath?: string;
}
export interface CreateFolderRequest {
    user_id: string;
    folderName: string;
    parentPath?: string;
}
export interface FolderItem {
    name: string;
    path: string;
    type: 'file' | 'folder';
    document?: Document;
}
export interface FolderListResponse {
    currentPath: string;
    folders: FolderItem[];
    files: FolderItem[];
}
export interface PresignedUrlResponse {
    uploadUrl: string;
    downloadUrl: string;
    s3Key: string;
    uploadType: 'simple' | 'multipart';
}
export interface MultipartUploadInitResponse {
    uploadId: string;
    s3Key: string;
    parts: MultipartUploadPart[];
    uploadType: 'multipart';
}
export interface MultipartUploadPart {
    partNumber: number;
    uploadUrl: string;
}
export interface MultipartUploadResponse {
    uploadUrl?: string;
    downloadUrl: string;
    s3Key: string;
    uploadType: 'simple' | 'multipart';
    uploadId?: string;
    parts?: MultipartUploadPart[];
}
export interface CompleteMultipartUploadRequest {
    uploadId: string;
    s3Key: string;
    parts: CompletedPart[];
}
export interface CompletedPart {
    partNumber: number;
    etag: string;
}
export interface UploadStatusResponse {
    status: 'pending' | 'completed' | 'failed' | 'aborted';
    uploadId?: string;
    s3Key: string;
    completedParts?: CompletedPart[];
}
export interface ListDocumentsResponse {
    documents: Document[];
    nextToken?: string;
}
export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    error?: string;
    message?: string;
}
//# sourceMappingURL=index.d.ts.map