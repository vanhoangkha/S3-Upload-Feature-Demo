import { Hono } from 'hono';
declare const documents: Hono<import("hono/types").BlankEnv, import("hono/types").BlankSchema, "/">;
export { documents };
//# sourceMappingURL=documents.d.ts.map