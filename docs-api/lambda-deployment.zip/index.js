"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const hono_1 = require("hono");
const cors_1 = require("hono/cors");
const logger_1 = require("hono/logger");
const pretty_json_1 = require("hono/pretty-json");
const documents_1 = require("./routes/documents");
const aws_config_1 = require("./utils/aws-config");
const auth_1 = require("./middleware/auth");
const logger_2 = require("./utils/logger");
const app = new hono_1.Hono();
// Middleware
app.use('*', (0, logger_1.logger)());
app.use('*', (0, pretty_json_1.prettyJSON)());
app.use('*', (0, cors_1.cors)({
    origin: (origin, c) => {
        // If allowedOrigins is true (wildcard), allow all origins
        if (aws_config_1.config.allowedOrigins === true) {
            return origin || '*';
        }
        // If allowedOrigins is an array, check if origin is included
        if (Array.isArray(aws_config_1.config.allowedOrigins)) {
            return aws_config_1.config.allowedOrigins.includes(origin || '') ? origin : null;
        }
        return null;
    },
    allowMethods: ['GET', 'POST', 'DELETE', 'PUT', 'PATCH', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    credentials: true,
}));
// Add optional authentication middleware to extract user context
app.use('*', auth_1.optionalAuthMiddleware);
// Health check endpoint
app.get('/health', (c) => {
    return c.json({
        success: true,
        message: 'API is healthy',
        data: {
            timestamp: new Date().toISOString(),
            service: 'docs-api',
            version: '1.0.0',
            environment: process.env.NODE_ENV || 'development'
        }
    });
});
// API routes
app.route('/vib-documents-function/api/documents', documents_1.documents);
// Root endpoint
app.get('/', (c) => {
    return c.json({
        success: true,
        message: 'Documents API Server',
        data: {
            endpoints: [
                'GET /health - Health check',
                'GET /vib-documents-function/api/documents - List documents',
                'GET /vib-documents-function/api/documents/folders - List folders and files',
                'POST /vib-documents-function/api/documents/folders - Create folder',
                'POST /vib-documents-function/api/documents/presigned-url - Generate presigned URLs',
                'POST /vib-documents-function/api/documents - Create document',
                'GET /vib-documents-function/api/documents/:user_id/:file - Get document',
                'GET /vib-documents-function/api/documents/:user_id/:file/download - Get download URL',
                'DELETE /vib-documents-function/api/documents/:user_id/:file - Delete document'
            ]
        }
    });
});
// 404 handler
app.notFound((c) => {
    return c.json({
        success: false,
        error: 'Not Found'
    }, 404);
});
// Error handler
app.onError((err, c) => {
    logger_2.logger.error('Unhandled error:', err);
    return c.json({
        success: false,
        error: 'Internal Server Error'
    }, 500);
});
exports.default = app;
//# sourceMappingURL=index.js.map