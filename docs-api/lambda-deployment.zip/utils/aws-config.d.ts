import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
import { S3Client } from '@aws-sdk/client-s3';
export declare const dynamoClient: DynamoDBClient;
export declare const docClient: DynamoDBDocumentClient;
export declare const s3Client: S3Client;
export declare const config: {
    documentsTableName: string;
    generalTableName: string;
    documentStoreBucketName: string;
    webStoreBucketName: string;
    region: string;
    presignedUrlExpiry: number;
    allowedOrigins: boolean | string[];
    cognitoUserPoolId: string | undefined;
    apiGatewayUrl: string | undefined;
};
//# sourceMappingURL=aws-config.d.ts.map