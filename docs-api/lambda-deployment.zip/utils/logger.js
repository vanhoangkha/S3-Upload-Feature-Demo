"use strict";
/**
 * Simple logger utility for the Documents API
 * Provides structured logging with different levels
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = exports.LogLevel = void 0;
var LogLevel;
(function (LogLevel) {
    LogLevel["ERROR"] = "ERROR";
    LogLevel["WARN"] = "WARN";
    LogLevel["INFO"] = "INFO";
    LogLevel["DEBUG"] = "DEBUG";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
class Logger {
    isDevelopment = process.env.NODE_ENV === 'development';
    log(level, message, data) {
        const logEntry = {
            level,
            message,
            timestamp: new Date().toISOString(),
            data
        };
        // In development, use pretty console logging
        if (this.isDevelopment) {
            const prefix = this.getColoredPrefix(level);
            if (data) {
                console.log(`${prefix} ${message}`, data);
            }
            else {
                console.log(`${prefix} ${message}`);
            }
        }
        else {
            // In production, use structured JSON logging
            console.log(JSON.stringify(logEntry));
        }
    }
    getColoredPrefix(level) {
        switch (level) {
            case LogLevel.ERROR:
                return '🔴 [ERROR]';
            case LogLevel.WARN:
                return '🟡 [WARN]';
            case LogLevel.INFO:
                return '🔵 [INFO]';
            case LogLevel.DEBUG:
                return '🟣 [DEBUG]';
            default:
                return '[LOG]';
        }
    }
    error(message, data) {
        this.log(LogLevel.ERROR, message, data);
    }
    warn(message, data) {
        this.log(LogLevel.WARN, message, data);
    }
    info(message, data) {
        this.log(LogLevel.INFO, message, data);
    }
    debug(message, data) {
        // Only log debug messages in development
        if (this.isDevelopment) {
            this.log(LogLevel.DEBUG, message, data);
        }
    }
    // Server startup logging with special formatting
    serverInfo(message, data) {
        if (this.isDevelopment) {
            console.log(`🚀 ${message}`, data ? data : '');
        }
        else {
            this.info(message, data);
        }
    }
    configInfo(message) {
        if (this.isDevelopment) {
            console.log(`📊 ${message}`);
        }
        else {
            this.info(message);
        }
    }
}
exports.logger = new Logger();
//# sourceMappingURL=logger.js.map