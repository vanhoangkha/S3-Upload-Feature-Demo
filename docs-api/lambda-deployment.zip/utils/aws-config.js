"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.s3Client = exports.docClient = exports.dynamoClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
// AWS configuration - uses default credential chain
// This will automatically use:
// 1. Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY) if set
// 2. AWS CLI profile (~/.aws/credentials)
// 3. EC2 instance profile (if running on EC2)
// 4. ECS task role (if running on ECS)
// 5. Lambda execution role (if running on Lambda)
const awsConfig = {
    region: process.env.AWS_REGION || 'us-east-1',
};
// Initialize AWS clients
exports.dynamoClient = new client_dynamodb_1.DynamoDBClient(awsConfig);
exports.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(exports.dynamoClient);
exports.s3Client = new client_s3_1.S3Client(awsConfig);
// Environment variables
exports.config = {
    documentsTableName: process.env.DOCUMENTS_TABLE_NAME || 'Documents',
    generalTableName: process.env.GENERAL_TABLE_NAME || 'General',
    documentStoreBucketName: process.env.DOCUMENT_STORE_BUCKET_NAME || 'vibdmsstore2026',
    webStoreBucketName: process.env.WEB_STORE_BUCKET_NAME || 'vibdmswebstore2026',
    region: process.env.AWS_REGION || 'us-east-1',
    presignedUrlExpiry: parseInt(process.env.PRESIGNED_URL_EXPIRY || '3600'),
    allowedOrigins: process.env.ALLOWED_ORIGINS === '*'
        ? true
        : (process.env.ALLOWED_ORIGINS || 'http://localhost:3000').split(','),
    cognitoUserPoolId: process.env.COGNITO_USER_POOL_ID,
    apiGatewayUrl: process.env.API_GATEWAY_URL,
};
//# sourceMappingURL=aws-config.js.map