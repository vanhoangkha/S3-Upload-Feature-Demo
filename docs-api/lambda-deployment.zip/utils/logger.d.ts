/**
 * Simple logger utility for the Documents API
 * Provides structured logging with different levels
 */
export declare enum LogLevel {
    ERROR = "ERROR",
    WARN = "WARN",
    INFO = "INFO",
    DEBUG = "DEBUG"
}
export interface LogEntry {
    level: LogLevel;
    message: string;
    timestamp: string;
    data?: any;
}
declare class Logger {
    private isDevelopment;
    private log;
    private getColoredPrefix;
    error(message: string, data?: any): void;
    warn(message: string, data?: any): void;
    info(message: string, data?: any): void;
    debug(message: string, data?: any): void;
    serverInfo(message: string, data?: any): void;
    configInfo(message: string): void;
}
export declare const logger: Logger;
export {};
//# sourceMappingURL=logger.d.ts.map