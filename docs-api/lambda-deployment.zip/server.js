"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_server_1 = require("@hono/node-server");
const index_1 = __importDefault(require("./index"));
const aws_config_1 = require("./utils/aws-config");
const logger_1 = require("./utils/logger");
// Load environment variables
const PORT = parseInt(process.env.PORT || '3001');
logger_1.logger.serverInfo('Starting Documents API Server...');
logger_1.logger.configInfo('Configuration:');
logger_1.logger.configInfo(`  - Port: ${PORT}`);
logger_1.logger.configInfo(`  - Environment: ${process.env.NODE_ENV || 'development'}`);
logger_1.logger.configInfo(`  - AWS Region: ${aws_config_1.config.region}`);
logger_1.logger.configInfo(`  - DynamoDB Tables: ${aws_config_1.config.documentsTableName}, ${aws_config_1.config.generalTableName}`);
logger_1.logger.configInfo(`  - S3 Buckets: ${aws_config_1.config.documentStoreBucketName}, ${aws_config_1.config.webStoreBucketName}`);
logger_1.logger.configInfo(`  - CORS Origins: *`);
(0, node_server_1.serve)({
    fetch: index_1.default.fetch,
    port: PORT,
}, (info) => {
    logger_1.logger.serverInfo(`Server running on http://localhost:${info.port}`);
    logger_1.logger.info('Available endpoints:');
    logger_1.logger.info('  - GET  /health');
    logger_1.logger.info('  - GET  /vib-documents-function/api/documents');
    logger_1.logger.info('  - GET  /vib-documents-function/api/documents/folders');
    logger_1.logger.info('  - POST /vib-documents-function/api/documents/folders');
    logger_1.logger.info('  - POST /vib-documents-function/api/documents/presigned-url');
    logger_1.logger.info('  - POST /vib-documents-function/api/documents');
    logger_1.logger.info('  - GET  /vib-documents-function/api/documents/:user_id/:file');
    logger_1.logger.info('  - GET  /vib-documents-function/api/documents/:user_id/:file/download');
    logger_1.logger.info('  - DELETE /vib-documents-function/api/documents/:user_id/:file');
});
//# sourceMappingURL=server.js.map