import { Document, CreateDocumentRequest, CreateFolderRequest, FolderListResponse } from '../types';
export declare class DocumentService {
    createDocument(data: CreateDocumentRequest & {
        s3Key: string;
        uploadedBy: string;
    }): Promise<Document>;
    createFolder(data: CreateFolderRequest): Promise<Document>;
    listFolderContents(user_id: string, folderPath?: string): Promise<FolderListResponse>;
    getDocument(user_id: string, file: string): Promise<Document | null>;
    getDocumentsByUserId(user_id: string, limit?: number, lastEvaluatedKey?: any): Promise<{
        documents: Document[];
        nextToken?: string;
    }>;
    deleteDocument(user_id: string, file: string): Promise<boolean>;
    deleteFolder(user_id: string, folderPath: string): Promise<boolean>;
    listAllDocuments(limit?: number, lastEvaluatedKey?: any): Promise<{
        documents: Document[];
        nextToken?: string;
    }>;
}
//# sourceMappingURL=document-service.d.ts.map