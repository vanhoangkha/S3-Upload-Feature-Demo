"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Service = void 0;
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const client_s3_1 = require("@aws-sdk/client-s3");
const aws_config_1 = require("../utils/aws-config");
const logger_1 = require("../utils/logger");
class S3Service {
    // Threshold for multipart upload (1GB - most files will use simple upload)
    MULTIPART_THRESHOLD = 1024 * 1024 * 1024;
    // Size of each part for multipart upload (100MB)
    PART_SIZE = 100 * 1024 * 1024;
    async generatePresignedUrls(fileName, mimeType, user_id, fileSize, folderPath) {
        // Use the format: protected/user_id/[folderPath/]filename
        // If folderPath is provided, include it in the S3 key
        let s3Key = `protected/${user_id}/`;
        if (folderPath && folderPath.trim()) {
            // Ensure folder path doesn't start or end with slashes and normalize it
            const normalizedPath = folderPath.trim().replace(/^\/+|\/+$/g, '').replace(/\/+/g, '/');
            if (normalizedPath) {
                s3Key += `${normalizedPath}/`;
            }
        }
        // Handle duplicate files by checking for existing files and creating versions
        const versionedFileName = await this.getVersionedFileName(s3Key, fileName);
        s3Key += versionedFileName;
        // Determine if we should use multipart upload
        const useMultipart = fileSize && fileSize > this.MULTIPART_THRESHOLD;
        if (useMultipart) {
            return this.initializeMultipartUpload(s3Key, mimeType, fileSize);
        }
        else {
            return this.generateSimpleUploadUrl(s3Key, mimeType);
        }
    }
    async generateSimpleUploadUrl(s3Key, mimeType) {
        // Generate presigned URL for simple upload
        const putCommand = new client_s3_1.PutObjectCommand({
            Bucket: aws_config_1.config.documentStoreBucketName,
            Key: s3Key,
            ContentType: mimeType,
        });
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(aws_config_1.s3Client, putCommand, {
            expiresIn: aws_config_1.config.presignedUrlExpiry,
        });
        // Generate presigned URL for download
        const downloadUrl = await this.getDownloadUrl(s3Key);
        return {
            uploadUrl,
            downloadUrl,
            s3Key,
            uploadType: 'simple'
        };
    }
    async initializeMultipartUpload(s3Key, mimeType, fileSize) {
        // Create multipart upload
        const createCommand = new client_s3_1.CreateMultipartUploadCommand({
            Bucket: aws_config_1.config.documentStoreBucketName,
            Key: s3Key,
            ContentType: mimeType,
        });
        const createResponse = await aws_config_1.s3Client.send(createCommand);
        const uploadId = createResponse.UploadId;
        // Calculate number of parts
        const numParts = Math.ceil(fileSize / this.PART_SIZE);
        const parts = [];
        // Generate presigned URLs for each part
        for (let partNumber = 1; partNumber <= numParts; partNumber++) {
            const uploadPartCommand = new client_s3_1.UploadPartCommand({
                Bucket: aws_config_1.config.documentStoreBucketName,
                Key: s3Key,
                PartNumber: partNumber,
                UploadId: uploadId,
            });
            const partUploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(aws_config_1.s3Client, uploadPartCommand, {
                expiresIn: aws_config_1.config.presignedUrlExpiry,
            });
            parts.push({
                partNumber,
                uploadUrl: partUploadUrl,
            });
        }
        // Generate download URL
        const downloadUrl = await this.getDownloadUrl(s3Key);
        return {
            downloadUrl,
            s3Key,
            uploadType: 'multipart',
            uploadId,
            parts
        };
    }
    async completeMultipartUpload(request) {
        try {
            const completeCommand = new client_s3_1.CompleteMultipartUploadCommand({
                Bucket: aws_config_1.config.documentStoreBucketName,
                Key: request.s3Key,
                UploadId: request.uploadId,
                MultipartUpload: {
                    Parts: request.parts.map(part => ({
                        ETag: part.etag,
                        PartNumber: part.partNumber,
                    })),
                },
            });
            await aws_config_1.s3Client.send(completeCommand);
            return true;
        }
        catch (error) {
            logger_1.logger.error('Error completing multipart upload:', error);
            return false;
        }
    }
    async abortMultipartUpload(uploadId, s3Key) {
        try {
            const abortCommand = new client_s3_1.AbortMultipartUploadCommand({
                Bucket: aws_config_1.config.documentStoreBucketName,
                Key: s3Key,
                UploadId: uploadId,
            });
            await aws_config_1.s3Client.send(abortCommand);
            return true;
        }
        catch (error) {
            logger_1.logger.error('Error aborting multipart upload:', error);
            return false;
        }
    }
    async getUploadStatus(uploadId, s3Key) {
        try {
            const listPartsCommand = new client_s3_1.ListPartsCommand({
                Bucket: aws_config_1.config.documentStoreBucketName,
                Key: s3Key,
                UploadId: uploadId,
            });
            const response = await aws_config_1.s3Client.send(listPartsCommand);
            const completedParts = response.Parts?.map(part => ({
                partNumber: part.PartNumber,
                etag: part.ETag,
            })) || [];
            return {
                status: 'pending',
                uploadId,
                s3Key,
                completedParts,
            };
        }
        catch (error) {
            logger_1.logger.error('Error getting upload status:', error);
            return {
                status: 'failed',
                s3Key,
            };
        }
    }
    async getDownloadUrl(s3Key) {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: aws_config_1.config.documentStoreBucketName,
            Key: s3Key,
        });
        return await (0, s3_request_presigner_1.getSignedUrl)(aws_config_1.s3Client, command, {
            expiresIn: aws_config_1.config.presignedUrlExpiry,
        });
    }
    async deleteObject(s3Key) {
        try {
            const command = new client_s3_1.DeleteObjectCommand({
                Bucket: aws_config_1.config.documentStoreBucketName,
                Key: s3Key,
            });
            await aws_config_1.s3Client.send(command);
            return true;
        }
        catch (error) {
            logger_1.logger.error('Error deleting S3 object:', error);
            return false;
        }
    }
    async checkObjectExists(s3Key) {
        try {
            const command = new client_s3_1.GetObjectCommand({
                Bucket: aws_config_1.config.documentStoreBucketName,
                Key: s3Key,
            });
            await aws_config_1.s3Client.send(command);
            return true;
        }
        catch (error) {
            return false;
        }
    }
    // Method to upload an object directly to S3 (for small files like folder metadata)
    async uploadObject(key, body, contentType = 'text/plain') {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: aws_config_1.config.documentStoreBucketName,
            Key: key,
            Body: body,
            ContentType: contentType,
        });
        await aws_config_1.s3Client.send(command);
    }
    // List objects in S3 bucket with a specific prefix (useful for folder detection)
    async listObjects(prefix, maxKeys = 1000) {
        try {
            const command = new client_s3_1.ListObjectsV2Command({
                Bucket: aws_config_1.config.documentStoreBucketName,
                Prefix: prefix,
                MaxKeys: maxKeys,
            });
            const response = await aws_config_1.s3Client.send(command);
            return response.Contents?.map(object => ({
                key: object.Key,
                lastModified: object.LastModified,
                size: object.Size,
                etag: object.ETag
            })) || [];
        }
        catch (error) {
            logger_1.logger.error('Error listing S3 objects:', error);
            return [];
        }
    }
    // Handle file versioning for duplicate filenames
    async getVersionedFileName(basePath, fileName) {
        // Check if the original filename already exists
        const originalKey = basePath + fileName;
        const exists = await this.checkObjectExists(originalKey);
        if (!exists) {
            // File doesn't exist, use original name
            return fileName;
        }
        // File exists, create a versioned name
        const fileExtension = fileName.includes('.')
            ? fileName.substring(fileName.lastIndexOf('.'))
            : '';
        const baseName = fileName.includes('.')
            ? fileName.substring(0, fileName.lastIndexOf('.'))
            : fileName;
        // Find the next available version number
        let version = 1;
        let versionedFileName;
        do {
            version++;
            versionedFileName = `${baseName} (${version})${fileExtension}`;
            const versionedKey = basePath + versionedFileName;
            const versionExists = await this.checkObjectExists(versionedKey);
            if (!versionExists) {
                break;
            }
            // Safety check to prevent infinite loop
            if (version > 1000) {
                // Use timestamp as fallback
                const timestamp = Date.now();
                versionedFileName = `${baseName}_${timestamp}${fileExtension}`;
                break;
            }
        } while (true);
        logger_1.logger.info(`File versioning: "${fileName}" -> "${versionedFileName}"`);
        return versionedFileName;
    }
}
exports.S3Service = S3Service;
//# sourceMappingURL=s3-service.js.map