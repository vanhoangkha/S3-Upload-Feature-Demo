import { MultipartUploadResponse, CompleteMultipartUploadRequest, UploadStatusResponse } from '../types';
export declare class S3Service {
    private readonly MULTIPART_THRESHOLD;
    private readonly PART_SIZE;
    generatePresignedUrls(fileName: string, mimeType: string, user_id: string, fileSize?: number, folderPath?: string): Promise<MultipartUploadResponse>;
    private generateSimpleUploadUrl;
    private initializeMultipartUpload;
    completeMultipartUpload(request: CompleteMultipartUploadRequest): Promise<boolean>;
    abortMultipartUpload(uploadId: string, s3Key: string): Promise<boolean>;
    getUploadStatus(uploadId: string, s3Key: string): Promise<UploadStatusResponse>;
    getDownloadUrl(s3Key: string): Promise<string>;
    deleteObject(s3Key: string): Promise<boolean>;
    checkObjectExists(s3Key: string): Promise<boolean>;
    uploadObject(key: string, body: string, contentType?: string): Promise<void>;
    listObjects(prefix: string, maxKeys?: number): Promise<any[]>;
    private getVersionedFileName;
}
//# sourceMappingURL=s3-service.d.ts.map