"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentService = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const aws_config_1 = require("../utils/aws-config");
const logger_1 = require("../utils/logger");
const uuid_1 = require("uuid");
class DocumentService {
    async createDocument(data) {
        const now = new Date().toISOString();
        // Use the S3 key as the unique identifier to handle files with same names in different folders
        // This ensures that files with the same name in different folders get separate DynamoDB records
        const document = {
            user_id: data.user_id,
            file: data.s3Key, // Use S3 key instead of just fileName to ensure uniqueness across folders
            id: (0, uuid_1.v4)(),
            title: data.title,
            description: data.description,
            fileSize: data.fileSize,
            mimeType: data.mimeType,
            s3Key: data.s3Key,
            uploadedBy: data.uploadedBy,
            createdAt: now,
            updatedAt: now,
            bucket: aws_config_1.config.documentStoreBucketName,
            itemType: 'file',
            folderPath: data.folderPath || '',
            isActive: true,
        };
        const command = new lib_dynamodb_1.PutCommand({
            TableName: aws_config_1.config.documentsTableName,
            Item: document,
        });
        await aws_config_1.docClient.send(command);
        return document;
    }
    async createFolder(data) {
        const now = new Date().toISOString();
        const folderPath = data.parentPath ? `${data.parentPath}/${data.folderName}` : data.folderName;
        // Create a folder record in DynamoDB
        const folderRecord = {
            user_id: data.user_id,
            file: `__FOLDER__${folderPath}`, // Special prefix to identify folders
            id: (0, uuid_1.v4)(),
            title: data.folderName,
            description: `Folder: ${data.folderName}`,
            fileSize: 0,
            mimeType: 'application/x-directory',
            s3Key: '', // Folders don't have S3 keys
            uploadedBy: data.user_id,
            createdAt: now,
            updatedAt: now,
            bucket: aws_config_1.config.documentStoreBucketName,
            itemType: 'folder',
            folderPath: data.parentPath || '',
            isActive: true,
        };
        const command = new lib_dynamodb_1.PutCommand({
            TableName: aws_config_1.config.documentsTableName,
            Item: folderRecord,
        });
        await aws_config_1.docClient.send(command);
        return folderRecord;
    }
    async listFolderContents(user_id, folderPath = '') {
        // Query all items for the user that belong to the specified folder
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: aws_config_1.config.documentsTableName,
            KeyConditionExpression: 'user_id = :user_id',
            FilterExpression: 'folderPath = :folderPath AND attribute_exists(isActive) AND isActive = :isActive',
            ExpressionAttributeValues: {
                ':user_id': user_id,
                ':folderPath': folderPath,
                ':isActive': true,
            },
        });
        const result = await aws_config_1.docClient.send(command);
        const items = result.Items || [];
        // Separate folders and files
        const folders = items
            .filter(item => item.itemType === 'folder')
            .map(folder => ({
            name: folder.title,
            path: folder.file.replace('__FOLDER__', ''), // Remove folder prefix
            type: 'folder',
        }));
        const files = items
            .filter(item => item.itemType === 'file')
            .map(file => ({
            name: file.title,
            path: file.s3Key,
            type: 'file',
            document: file,
        }));
        return {
            currentPath: folderPath,
            folders: folders.sort((a, b) => a.name.localeCompare(b.name)),
            files: files.sort((a, b) => a.name.localeCompare(b.name)),
        };
    }
    async getDocument(user_id, file) {
        const command = new lib_dynamodb_1.GetCommand({
            TableName: aws_config_1.config.documentsTableName,
            Key: { user_id, file },
        });
        const result = await aws_config_1.docClient.send(command);
        return result.Item || null;
    }
    async getDocumentsByUserId(user_id, limit = 20, lastEvaluatedKey) {
        const command = new lib_dynamodb_1.QueryCommand({
            TableName: aws_config_1.config.documentsTableName,
            KeyConditionExpression: 'user_id = :user_id',
            FilterExpression: 'itemType = :itemType AND attribute_exists(isActive) AND isActive = :isActive',
            ExpressionAttributeValues: {
                ':user_id': user_id,
                ':itemType': 'file',
                ':isActive': true,
            },
            Limit: limit,
            ExclusiveStartKey: lastEvaluatedKey,
        });
        const result = await aws_config_1.docClient.send(command);
        return {
            documents: result.Items || [],
            nextToken: result.LastEvaluatedKey ? JSON.stringify(result.LastEvaluatedKey) : undefined,
        };
    }
    // Document update functionality removed - edit functionality is no longer supported
    async deleteDocument(user_id, file) {
        // Soft delete - mark as inactive instead of hard delete
        const now = new Date().toISOString();
        const command = new lib_dynamodb_1.PutCommand({
            TableName: aws_config_1.config.documentsTableName,
            Item: {
                user_id,
                file,
                isActive: false,
                updatedAt: now,
            },
            // Use ConditionExpression to ensure the item exists
            ConditionExpression: 'attribute_exists(user_id) AND attribute_exists(file)',
        });
        try {
            await aws_config_1.docClient.send(command);
            return true;
        }
        catch (error) {
            logger_1.logger.error('Error soft deleting document:', error);
            return false;
        }
    }
    async deleteFolder(user_id, folderPath) {
        try {
            // First, get all items in the folder (both subfolders and files)
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: aws_config_1.config.documentsTableName,
                KeyConditionExpression: 'user_id = :user_id',
                FilterExpression: 'begins_with(folderPath, :folderPath) AND attribute_exists(isActive) AND isActive = :isActive',
                ExpressionAttributeValues: {
                    ':user_id': user_id,
                    ':folderPath': folderPath,
                    ':isActive': true,
                },
            });
            const result = await aws_config_1.docClient.send(command);
            const items = result.Items || [];
            // Soft delete all items in the folder
            const now = new Date().toISOString();
            const deletePromises = items.map(item => {
                const deleteCommand = new lib_dynamodb_1.PutCommand({
                    TableName: aws_config_1.config.documentsTableName,
                    Item: {
                        ...item,
                        isActive: false,
                        updatedAt: now,
                    },
                });
                return aws_config_1.docClient.send(deleteCommand);
            });
            // Also delete the folder itself
            const folderDeleteCommand = new lib_dynamodb_1.PutCommand({
                TableName: aws_config_1.config.documentsTableName,
                Item: {
                    user_id,
                    file: `__FOLDER__${folderPath}`,
                    isActive: false,
                    updatedAt: now,
                },
            });
            deletePromises.push(aws_config_1.docClient.send(folderDeleteCommand));
            await Promise.all(deletePromises);
            return true;
        }
        catch (error) {
            logger_1.logger.error('Error deleting folder:', error);
            return false;
        }
    }
    async listAllDocuments(limit = 20, lastEvaluatedKey) {
        const command = new lib_dynamodb_1.ScanCommand({
            TableName: aws_config_1.config.documentsTableName,
            FilterExpression: 'itemType = :itemType AND attribute_exists(isActive) AND isActive = :isActive',
            ExpressionAttributeValues: {
                ':itemType': 'file',
                ':isActive': true,
            },
            Limit: limit,
            ExclusiveStartKey: lastEvaluatedKey,
        });
        const result = await aws_config_1.docClient.send(command);
        return {
            documents: result.Items || [],
            nextToken: result.LastEvaluatedKey ? JSON.stringify(result.LastEvaluatedKey) : undefined,
        };
    }
}
exports.DocumentService = DocumentService;
//# sourceMappingURL=document-service.js.map