import { Context, Next } from 'hono';
import { AuthenticatedUser, CognitoUser, AuthContext } from '../types/auth';
declare module 'hono' {
    interface ContextVariableMap {
        authContext: AuthContext;
    }
}
/**
 * Extract JWT claims from Authorization header (for direct JWT parsing)
 */
export declare function extractJWTClaims(authHeader: string): CognitoUser | null;
/**
 * Extract Cognito user information from API Gateway Lambda event
 */
export declare function extractCognitoUser(c: Context): AuthenticatedUser | null;
/**
 * Authentication middleware that extracts user context from Cognito JWT
 */
export declare function authMiddleware(c: Context, next: Next): Promise<(Response & import("hono").TypedResponse<{
    success: false;
    error: string;
}, 401, "json">) | undefined>;
/**
 * Optional authentication middleware (allows both authenticated and unauthenticated requests)
 */
export declare function optionalAuthMiddleware(c: Context, next: Next): Promise<void>;
/**
 * Admin-only middleware
 */
export declare function adminOnlyMiddleware(c: Context, next: Next): Promise<(Response & import("hono").TypedResponse<{
    success: false;
    error: string;
}, 403, "json">) | undefined>;
/**
 * User resource access middleware - ensures users can only access their own resources
 */
export declare function userResourceMiddleware(c: Context, next: Next): Promise<(Response & import("hono").TypedResponse<{
    success: false;
    error: string;
}, 401, "json">) | (Response & import("hono").TypedResponse<{
    success: false;
    error: string;
}, 403, "json">) | undefined>;
/**
 * Helper function to get current authenticated user
 */
export declare function getCurrentUser(c: Context): AuthenticatedUser | null;
/**
 * Helper function to check if current user is admin
 */
export declare function isCurrentUserAdmin(c: Context): boolean;
//# sourceMappingURL=auth.d.ts.map